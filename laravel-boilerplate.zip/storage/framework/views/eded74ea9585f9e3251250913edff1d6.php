<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-0 container-fluid">
        <h1 class="mb-3 h2"><strong>Dashboard</strong></h1>
        <div class="row">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="mt-0 col">
                            <h5 class="text-center text-black card-title"><?php echo e(__("You're logged in!")); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-boilerplate\resources\views/dashboard.blade.php ENDPATH**/ ?>