<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col text-start">
                <p class="mb-0">
                    <a class="text-muted" href="https://medquest.co.id/" target="_blank"><strong>ITD
                            Medquest</strong></a> - <a class="text-muted" href="https://adminkit.io/"
                        target="_blank"><strong>Template by AdminKit</strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
