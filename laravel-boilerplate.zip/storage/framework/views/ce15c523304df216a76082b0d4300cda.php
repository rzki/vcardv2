<?php $__env->startSection('title', 'My Profile'); ?>
<?php $__env->startSection('content'); ?>
<div class="p-0 container-fluid">
    <h1 class="mb-3 h2"><strong><?php echo e(__('My Profile')); ?></strong></h1>
    <div class="row">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="mt-0 col">
                        <form action="<?php echo e(route('profile.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>

                            <div class="mb-3 form-group">
                                <label for="name" class="text-black form-label fw-bold"><?php echo e(__('Name')); ?></label>
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="email" class="text-black form-label fw-bold"><?php echo e(__('Email')); ?></label>
                                <input type="text" name="email" id="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="current_password" class="text-black form-label fw-bold"><?php echo e(__('Current Password')); ?></label>
                                <input type="password" name="current_password" id="current_password" class="form-control" required autocomplete="current-password">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="password" class="text-black form-label fw-bold"><?php echo e(__('New Password')); ?></label>
                                <input type="password" name="password" id="password" class="form-control" required autocomplete="new-password">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="password_confirmation" class="text-black form-label fw-bold"><?php echo e(__('Confirm New Password')); ?></label>
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required autocomplete="confirm-new-password">
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-success"><?php echo e(__('Submit')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-boilerplate\resources\views/profiles/edit.blade.php ENDPATH**/ ?>